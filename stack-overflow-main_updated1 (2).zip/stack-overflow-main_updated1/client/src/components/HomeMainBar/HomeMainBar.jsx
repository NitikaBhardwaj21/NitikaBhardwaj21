import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./HomeMainBar.css";
import QuestionList from "./QuestionList";
import { useSelector } from "react-redux";
import moment from "moment";
// import Questions from "./Questions";
// import '../../App.css'

const HomeMainBar = () => {
  const [data, setData] = useState({
    city: null,
    region: null,
    country: null,
  });

  const [weatherData, setWeatherData] = useState({
    temp: null,
    weather: null,
  });

  const [time, setTime] = useState();

  const location = useLocation();
  const user = 1;
  const navigate = useNavigate();

  // Abuout useLocation
  // This hook returns the current location object. This can be useful if you'd like to perform some side effect whenever the current location changes.

  // import * as React from 'react';
  // import { useLocation } from 'react-router-dom';

  // function App() {
  //   let location = useLocation();

  //   React.useEffect(() => {
  //     // Google Analytics
  //     ga('send', 'pageview');
  //   }, [location]);

  //   return (
  //     // ...
  //   );
  // }

  // About useNavigate()
  // useNavigate is a React hook that allows you to programmatically navigate between different routes in a React application. It is used to provide a declarative way to navigate between routes, which makes it easier to maintain and update the application. It also allows for more flexibility when creating complex navigation flows.

  // The useNavigate hook returns a function that lets you navigate programmatically, for example in an effect:

  // import { useNavigate } from "react-router-dom";

  // function useLogoutTimer() {
  //   const userIsInactive = useFakeInactiveUser();
  //   const navigate = useNavigate();

  //   useEffect(() => {
  //     if (userIsInactive) {
  //       fake.logout();
  //       navigate("/session-timed-out");
  //     }
  //   }, [userIsInactive]);
  // }

  const questionList = useSelector((state) => state.questionReducer);
  // console.log(questionList, "It's question list...");

  // var questionList = [
  //   {
  //     _id: 1,
  //     votes: 3,
  //     upVotes: 3,
  //     downVotes: 2,
  //     noOfAnswers: 2,
  //     questionTitle: "What is a function",
  //     questionBody: "It mean to be",
  //     questionTags: ["Java", "node.js", "react.js", "mongoDB"],
  //     userPosted: "mano",
  //     userId: 1,
  //     askedOn: "jan 1",
  //     answer: [{
  //       answerBody: "Answer",
  //       userAnswered: "kumar",
  //       answerOn: "jan 2",
  //       userId: 1,
  //     }]

  //   },
  //   {
  //     _id: 2,
  //     votes: 0,
  //     upVotes: 3,
  //     downVotes: 2,
  //     noOfAnswers: 8,
  //     questionTitle: "What is a function",
  //     questionBody: "It mean to be",
  //     questionTags: ["Javascript", "R", "Python", "mongoDB"],
  //     userPosted: "mano",
  //     userId: 1,
  //     askedOn: "jan 1",
  //     answer: [{
  //       answerBody: "Answered",
  //       userAnswered: "kumar",
  //       answerOn: "jan 2",
  //       userId: 2,
  //     }]
  //   },
  //   {
  //     _id: 3,
  //     votes: 1,
  //     upVotes: 3,
  //     downVotes: 2,
  //     noOfAnswers: 0,
  //     questionTitle: "What is a function",
  //     questionBody: "It mean to be",
  //     questionTags: ["Javascript", "R", "Python", "mongoDB"],
  //     userPosted: "mano",
  //     askedOn: "jan 1",
  //     userId: 1,
  //     answer: [{
  //       answerBody: "Answered",
  //       userAnswered: "kumar",
  //       userAnsweredOn: "jan 2",
  //       userId: 2,
  //     }]
  //   },
  // ];

  const checkAuth = () => {
    if (user === null) {
      alert("Login or Signup fo ask a question...");
      navigate("/Auth");
    } else {
      navigate("/AskQuestions");
    }
  };

  let currentWeather;
  let currentWeatherId;
  let currentWeatherMain;
  let range;

  let amPm;

  let date = new Date();

  let hours = date.getHours();
  let minutes = date.getMinutes();
  let seconds = date.getSeconds();

  if (hours >= 12) {
    amPm = "PM";
  } else {
    amPm = "AM";
  }

  let thunderstorm;
  let drizzle;
  let atmosphere;
  let clouds;
  let rain;
  let snowClear;

  const fetchLocation = async () => {
    try {
      const response = await fetch("http://ip-api.com/json/");

      const resData = await response.json();

      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${resData.lat}&lon=${resData.lon}&appid=90986bfae3e5134681f24d3e858c2257&units=metric`
      );

      const data = await res.json();

      currentWeather = data.weather[0].description;
      currentWeatherMain = data.weather[0].main;
      currentWeatherId = data.weather[0].id;

      thunderstorm = currentWeatherMain === "Thunderstorm";
      drizzle = currentWeatherMain === "Drizzle";
      rain = currentWeatherMain === "Rain";
      snowClear =
        currentWeatherMain === "Snow" && currentWeatherMain === "Clear";
      clouds = currentWeatherMain === "Clouds";
      atmosphere = currentWeatherId > 700 ? currentWeatherId < 800 : null;

      if (
        // currentWeatherId === "overcast clouds" ||
        // currentWeatherId === "scattered clouds" ||
        // currentWeatherId === "broken clouds"
        clouds
      ) {
        document.body.style.backgroundColor = "rgb(103, 96, 236)";
      }

      if (atmosphere || thunderstorm) {
        document.body.style.backgroundColor = "rgb(209, 216, 216)";
      }

      if (rain || drizzle || snowClear) {
        document.body.style.backgroundColor = "rgb(61, 143, 184)";
      }

      setData({
        city: `${resData.city},`,
        region: `${resData.regionName},`,
        country: resData.country,
      });

      setWeatherData({
        temp: `Temperature :- ${data.main.temp} °C`,
        weather: `Weather :- ${currentWeather}`,
      });

      setInterval(() => {
        setTime(`Time :- ${moment().format("hh:mm:ss")} ${amPm}`);
      }, 1000);
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <div className="main-bar">
      <div className="main-bar-header">
        {location.pathname === "/" ? (
          <h1>Top Questions</h1>
        ) : (
          <h1>All Questions</h1>
        )}
        <button onClick={checkAuth} className="ask-btn">
          Ask Question
        </button>
      </div>

      <div style={{ textAlign: "center", marginTop: "10px" }}>
        <button
          onClick={fetchLocation}
          style={{
            backgroundColor: "#009bff",
            color: "white",
            borderRadius: "4px",
            width: "125px",
            height: "35px",
          }}
        >
          Fetch Location
        </button>
        <p style={{ fontWeight: "bold" }}>
          {data.city} {data.region} {data.country}
        </p>
        <p style={{ fontWeight: "bold" }}>{weatherData.temp}</p>
        <p style={{ fontWeight: "bold" }}>{weatherData.weather}</p>
        <p style={{ fontWeight: "bold" }}>{time}</p>
      </div>

      <div>
        {questionList.data === null ? (
          <h1>Loading...</h1>
        ) : (
          <>
            <p>{questionList.data.length} Questions</p>
            <QuestionList questionList={questionList.data} />
          </>
        )}
      </div>
    </div>
  );
};

export default HomeMainBar;
